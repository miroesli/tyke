// Package version exports a version variable.
package version

// Version is the version of the controller. Set with build flags.
var Version = "unreleased"
