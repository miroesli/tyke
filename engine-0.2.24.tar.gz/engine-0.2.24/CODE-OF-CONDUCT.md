Code of Conduct
===

Please see https://github.com/battlesnakeio/community/blob/master/README.md#code-of-conduct
